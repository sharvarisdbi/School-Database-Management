SELECT * FROM student_database.parents_guardians;

CREATE TABLE student_database.parents_guardians(
  `student_id` CHAR(5) NOT NULL,
  `parent_id` CHAR(3) NOT NULL,
  `parent_name` VARCHAR(45) NULL,
  `guardian_name` VARCHAR(45) NULL,
  `role` VARCHAR(45) NULL,
  `contact_no` CHAR(10) NOT NULL,
  `email_id` VARCHAR(45) NULL,
  `mother_tongue` VARCHAR(45) NOT NULL,
  PRIMARY KEY (parent_id),
  FOREIGN KEY (student_id) REFERENCES students(student_id)
  );
  
   INSERT INTO student_database.parents_guardians (student_id,parent_name,parent_id,guardian_name,role,contact_no,email_id,mother_tongue) VALUES
  ('FY001','Yogesh Avhad','P01',null,'Father','9227192271','yogash.bhatia@gmail.com','marathi'),
  ('FY002','Srushti Bhatia','P02',null,'Mother','9871298712','srushti123@hotmail.com','hindi'),
  ('FY003','Rajan Chauhan','P03',null,'Father','9812421432','rajan10@yahoo.in','kutchchi'),
  ('FY004','Vaishnu Kaur','P04',null,'Father','9012587123',null,'punjabi'),
  ('FY005','Tejasvi Nandu','P05',null,'Father','8124576234',null,'marwadi'),
  ('FY006','Falit Shinde ','P06',null,'Father','7056281209','falit01@hotmail.com','hindi'),
  ('FY007','Megha Sharma ','P07',null,'Mother','7612891230',null,'sindhi'),
  ('FY008','Riya Karim ','P08',null,'Mother','9304567123',null,'hindi'),
  ('FY009','Sushma Khan','P09',null,'Mother','8712045109',null,'hindi'),
  ('FY010','Mamta Kanoja','P10',null,'Mother','7651065109','Mamta1976@gmail.com','hindi'),
  ('FY011',null,'P11','Aditi Mishra',null,'7100125123',null,'goan'),
  ('FY012',null,'P12','Shubham Kapadia',null,'9090187123','shubhaml@hotmail.com','sindhi'),
  ('FY013','Bansal Sinha','P13',null,'Father','8745081201',null,'marwadi'),
  ('FY014','Prachi Khan','P14',null,'Mother','9000187123','prachib65@yahoo.in','arabic'),
  ('FY015','Umesh Shinde','P15',null,'Father','8013167189',null,'marathi'),
  ('FY016','Uttkarsh Ail','P16',null,'Father','7123067180','utt1960@yahoo.in','hindi'),
  ('FY017',null,'P17','Yash Gupta',null,'8012365901',null,'hindi'),
  ('FY018','Nehal','P18',null,'father','7019278123','nehal60@gmail.com','marathi'),
  ('FY019',null,'P19','Krishita Patel',null,'9019067120',null,'gujarati'),
  ('FY020','Mukesh Dulera','P20',null,'Father','8001331008','mukeshg1968@hotmail.com','gujarati'),
  ('FY021','Damini Dsouza','P21',null,'Mother','7801231092','daminiux@yahoo.in','konkani'),
  ('FY022','Bhumi Gandhi','P22',null,'Mother','8900187109',null,'kutchchi'),
  ('FY023',null,'P23','Aditi Panchal',null,'9012789013',null,'hindi'),
  ('FY024','Vaibhav Shaikh','P24',null,'Father','7010890123',null,'hindi');