CREATE SCHEMA `student_database` ;

SELECT * FROM student_database.students;

CREATE TABLE student_database.students (
  `student_id` CHAR(5),
  `roll_no` INT NOT NULL,
  `first_name` VARCHAR(40) NOT NULL,
  `last_name` VARCHAR(40) DEFAULT NULL,
  `email_id` VARCHAR(30) DEFAULT NULL,
  `gender` VARCHAR(20) NULL,
  `religion` VARCHAR(20),
  `address` VARCHAR(255),
  `contact_no` CHAR(10) NOT NULL,
  `mother_tongue` VARCHAR(30) DEFAULT NULL,
  `date_of_birth` DATE NOT NULL,
  PRIMARY KEY (student_id));
  
INSERT INTO `student_database`.`students` (`student_id`, `roll_no`, `first_name`, `last_name`, `email_id`, `gender`, `religion`, `address`, `contact_no`, `mother_tongue`, `date_of_birth`) values
('FY001', 1, 'Sharvari', 'Avhad', 'sharvariavhad@gmail.com', 'female', 'hindu', 'Malad, Green heights, B62, Mumbai, Maharashtra', '9702335683', 'marathi', '2002-11-28'),
('FY002', 2, 'Pratham', 'Bhatia', 'prathambhatia741@gmail.com', 'male','hindu', 'Goregoan, Crystal Heights, A20, Mumbai, Maharashtra', '704575053', 'hindi', '2002-10-22'),
('FY003', 3, 'Shubham' , 'Ail' , 'ailshubham10@gmail.com' , 'male' , 'hindu' , 'Bandra, Star World, C26, Mumbai, Maharashtra', '9136500880', 'hindi' , '2001-01-14'),
('FY004', 4, 'Siya', 'Karim', 'siyakarim@gmail.com', 'female', 'muslim', 'Borivali, Mega Valley, B33, Mumbai, Maharashtra', '7685430222', 'hindi', '2002-09-23'),
('FY005', 5, 'Vaibhav',  'Dulera' , 'vaibhavdulera@gmail.com' , 'male' , 'hindu' , 'Goregoan, Saraswati Heights, A21, Mumbai, Maharashtra', '7506946948', 'gujarati' , '2002-12-18'),
('FY006', 6, 'Kirti', 'Sinha', 'kirtisinha@gmail.com', 'female', 'jain', 'Borivali,Kingston,B20,Mumbai,Maharashtra', '7689544321', 'marvadi', '2001-05-21'),
('FY007', 7, 'Aditya', 'Chauhan', 'adityachauhan2gmail.com', 'male', 'jain', 'Byculla,Green City,D13, Mumbai,Maharashtra', '8652355678', 'kutchchi', '2002-07-21'),
('FY008', 8, 'Saman', 'Khan', 'samankhan4@gmail.com', 'male', 'muslim', 'Grand Road, Manghlam, B23,  Mumbai, Maharashtra', '7822567554', 'arabic', '2001-06-09'),
('FY009', 9, 'Mahostav', 'Bhattarai', 'mahotasavbhattaria22@gmail.com', 'male', 'hindu', 'Malad, MIndspace, B09,  Mumbai, Maharashtra', '8654344679', 'gujarati', '2001-02-21'),
('FY010', 10, 'Mohan', 'Sharma', 'sharmamohan33@gmail.com', 'male', 'hindu', 'Bandra, Taj Colony , C24, Mumbai, Maharashtra', '8654344679', 'sindhi', '2001-06-30'),
('FY011', 11, 'Preet', 'Kaur', 'preetkaur@gmail.com', 'female', 'hindu', 'Chembur, Raj Victoria, C08,  Mumbai, Maharashtra', '8654347899', 'punjabi', '2001-11-21'),
('FY012', 12, 'Saloni', 'Shinde', 'salonishinde05@gmail.com', 'female', 'buddhist', 'Goregoan, Bhumi Heights, C05,  Mumbai, Maharashtra', '8755348893', 'marathi', '2002-10-11'),
('FY013', 13, 'Anjali', 'Nandu', 'nanduanjali@gmail.com', 'female', 'jain', 'Chembur, Edifice, A41,  Mumbai, Maharashtra', '8757814679', 'marvadi', '2002-12-11'),
('FY014', 14, 'Ranjan', 'Shinde', 'ranjans8@gmail.com', 'male', 'buddhist', 'Seawoods,Kshalp,C32, Mumbai,Maharashtra', '7955344679', 'hindi', '2002-11-24'),
('FY015', 15, 'Mehboob', 'Shaikh', 'mehboobshaikh445@gmail.com', 'male', 'muslim', 'Malad, Green heights,B71, Mumbai,Maharashtra', '8755344679', 'hindi', '2001-06-09'),
('FY016', 16, 'Seema', 'Kanojia', 'seemakanojia@gmail.com', 'female', 'hindu', 'Malad West,Interface Heights,C23, Mumbai,Maharashtra', '8835446791', 'hindi', '2002-08-14'),
('FY017', 17, 'Kirti', 'Khan', 'kirtikhan@gmail.com', 'female', 'muslim', 'Kandivali, Varun Apartment, D11,  Mumbai, Maharashtra', '7955344839', 'hindi', '2002-01-20'),
('FY018', 18, 'Abigail', 'Dsouza', 'abigail111@gmail.com', 'female', 'christain', 'Dahisar, Rajhans orange, A01, Mumbai, Maharashtra', '8256344679', 'konkani', '2000-07-21'),
('FY019', 19, 'Rabia', 'Kapadia', 'rabiakapadia@gmail.com', 'feale', 'hindu', 'Byculla, Stuti Empress,B62, Mumbai,Maharashtra’,‘Seawoods,Kshalp,C32, Mumbai,Maharashtra', '7956934679', 'sindhi', '2002-02-28'),
('FY020', 20, 'Arib', 'Ansari', 'ansariarib@gmail.com', 'male', 'muslim', 'Powai, Pratels Valley, C10,  Mumbai, Maharashtra', '8755344679', 'hindi', '2000-04-12'),
('FY021', 21, 'Arain', 'Vaaz', 'arainvaaz03@gmail.com', 'male', 'christain', 'Lower Parel, LordMount, B17,  Mumbai, Maharashtra', '8652344679', 'goan', '2002-10-16'),
('FY022', 22, 'Jasmine', 'Shaikh', 'shaikhjasmine@gmail.com', 'female', 'muslim', 'Andheri,Coral Heights,A15, Mumbai,Maharashtra', '7955348781', 'hindi', '2001-03-17'),
('FY023', 23, 'Sahil', 'Gaikwad', 'sahilgaikwad24@gmail.com', 'male', 'hindu', 'Ghatkopar,Vishnu Apartments,C03, Mumbai,Maharashtra', '7955344693', 'marathi', '2001-10-30'),
('FY024', 24, 'Bhavya', 'Gandhi', 'bhavyagandhi92@gmail.com', 'male', 'jain', 'Grant Road,Palais Royale,B21,Mumbai,Maharashtra', '9702773458', 'kutchchi', '2000-09-19');