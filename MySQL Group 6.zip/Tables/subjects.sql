SELECT * FROM student_database.subjects;

CREATE TABLE student_database.subjects (
  subject_id CHAR(3) NOT NULL,
  course_id CHAR(3) NOT NULL,
  subject_name VARCHAR(25) NOT NULL,
  PRIMARY KEY (subject_id),
  FOREIGN KEY (course_id) REFERENCES student_database.courses(course_id)
  );

INSERT INTO student_database.subjects(subject_id,course_id,subject_name) values
('PHY','SCI','physics'),
('BIO','SCI','biology'),
('CHE','SCI','chemistry'),
('SMA','SCI','math'),
('SEN','SCI','english'),
('ACC','COM','accounts'),
('ECO','COM','economics'),
('OCM','COM','organisation of commerce'),
('CMA','COM','math'),
('CEN','COM','english'),
('PSY','ART','psychology'),
('POS','ART','political science'),
('HIS','ART','history'),
('AMA','ART','math'),
('AEN','ART','english');

