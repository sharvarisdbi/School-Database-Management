SELECT * FROM student_database.coursework_subject;

CREATE TABLE student_database.coursework_subject (
  `coursework_id` VARCHAR(20) NOT NULL,
  `subject_id` CHAR(3) NOT NULL,
  `coursework_name` VARCHAR(20) NOT NULL,
  `max_marks` INT NOT NULL,
  `course_year` INT NOT NULL,
  `course_semester` INT NOT NULL,
  PRIMARY KEY (`coursework_id`),
  FOREIGN KEY (`subject_id`) REFERENCES student_database.subjects(subject_id)
  );

INSERT INTO student_database.coursework_subject 
(`coursework_id`,`subject_id`,`coursework_name`,`max_marks`,`course_year`,`course_semester`) VALUES
('PHY_EC','PHY','ELECTRIC CURRENT',20,2019,1),
('PHY_LR','PHY','LIGHT RAYS',20,2019,2),
('BIO_PK','BIO','PLANT KINGDOM',20,2019,1),
('BIO_AK','BIO','ANIMAL KINGDOM',20,2019,2),
('SMA_DI','SMA','DERIVATIVES',20,2019,1),
('SMA_MAT','SMA','MATRICES',20,2019,2),
('ACC_FA','ACC','FINAL ACCOUNTS',20,2019,1),
('ACC_PF','ACC','PARTNERSHIP FIRM',20,2019,2),
('ECO_ES','ECO','ELASTICITY OF SUPPLY',20,2019,1),
('ECO_ED','ECO','ELASTICITY OF DEMAND',20,2019,2),
('CMA_LI', 'CMA', 'LINE', 20, 2019,1),
('CMA_PC', 'CMA', 'PERMUTATION', 20, 2019, 2),
('PSY_IP', 'PSY', 'INVESTER PSYCHOLOGY', 20, 2019, 1),
('PSY_TP', 'PSY', 'PERSPECTIVE', 20, 2019, 2),
('HIS_WW', 'HIS', 'WORLD WAR 1', 20, 2019, 1),
('HIS_DM', 'HIS', 'DANDI MARCH', 20, 2019, 2),
('AMA_IN', 'AMA', 'INTEGRATION', 20, 2019, 1),
('AMA_DE', 'AMA', 'DERIVATIVES', 20, 2019, 2);
