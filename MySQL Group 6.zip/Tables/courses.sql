CREATE TABLE student_database.courses (
  course_id CHAR(3) NOT NULL,
  course_name VARCHAR(20) NOT NULL,
  PRIMARY KEY (course_id));

  INSERT INTO student_database.courses(course_id,course_name)values
  ('SCI','science'),
  ('COM','commerce'),
  ('ART','arts');

SELECT*FROM  student_database.courses;
