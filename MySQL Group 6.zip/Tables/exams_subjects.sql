SELECT * FROM student_database.exams_subjects;

CREATE TABLE student_database.exams_subjects (
  exam_id CHAR(5) NOT NULL,
  subject_id CHAR(3) NOT NULL,
  exam_date DATE NOT NULL,
  max_marks INT NOT NULL,
  PRIMARY KEY (exam_id),
  FOREIGN KEY (subject_id) REFERENCES subjects(subject_id)
  );
  
INSERT INTO student_database.exams_subjects (exam_id,subject_id,exam_date,max_marks) VALUES
('EXPHY','PHY','2020-12-3',50),
('EXBIO','BIO','2020-12-4',50),
('EXCHE','CHE','2020-12-5',50),
('EXSMA','SMA','2020-12-6',50),
('EXSEN','SEN','2020-12-7',50),
('EXACC','ACC','2020-12-3',50),
('EXECO','ECO','2020-12-4',50),
('EXOCM','OCM','2020-12-5',50),
('EXCMA','CMA','2020-12-6',50),
('EXCEN','CEN','2020-12-7',50),
('EXPSY','PSY','2020-12-3',50),
('EXPOS','POS','2020-12-4',50),
('EXHIS','HIS','2020-12-5',50),
('EXAMA','AMA','2020-12-6',50),
('EXAEN','AEN','2020-12-7',50);
