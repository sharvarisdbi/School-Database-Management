#1
SELECT * FROM students WHERE first_name LIKE 'S%';

#2
SELECT CONCAT(first_name, ' ', last_name) as 'full_name', gender, religion FROM student_database.students
WHERE gender='female' AND religion='hindu';

#3
SELECT parent_name, guardian_name, email_id FROM parents_guardians where email_id is NULL;

#4
SELECT MIN(marks_obtained) AS 'Minimum Marks' FROM student_database.student_exam;

#5
SELECT MAX(marks_obtained) AS 'Maximum Marks' FROM student_database.student_exam;

#6
SELECT AVG(marks_obtained) AS 'Average Marks' FROM student_database.student_exam;

#7
SELECT student_id, SUM(marks_obtained) AS 'Total Marks',
CASE
    WHEN SUM(marks_obtained) > 150 THEN 'PASSED'
    ELSE 'FAILED'
END AS Result
FROM student_exam
GROUP BY student_id;

#8
SELECT s.student_id, SUM(s.marks_obtained) AS 'Total Marks', SUM(exams_subjects.max_marks) AS 'Max Marks', CONCAT(ROUND(((SUM(s.marks_obtained)/SUM(exams_subjects.max_marks)) * 100 ),2),'%') AS 'Percentage'
FROM student_exam as s
INNER JOIN exams_subjects
ON s.exam_id = exams_subjects.exam_id
GROUP BY s.student_id;

#9
SELECT * FROM student_database.coursework_student_name
WHERE coursework_id IN ('PHY_EC','PHY_LR')
ORDER BY marks_obtained DESC;

#10
SELECT student_id,coursework_id,marks_obtained
FROM coursework_student_name
WHERE marks_obtained BETWEEN 5 AND 12; 

#11
SELECT s.student_id , s.first_name, student_exam.marks_obtained, student_exam.exam_id
FROM students AS s
INNER JOIN student_exam ON s.student_id=student_exam.student_id
GROUP BY s.student_id, student_exam.exam_id;

